package edit_xlsx_01;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XSLX {

	private static final Logger LOGGER = Logger.getLogger("Main");
	
	FileInputStream fileInputS = null;
	XSSFWorkbook fileXSLX = null;
	FileOutputStream fileOutputS = null;
	File filePrdOrig, filePrdMod;
	XSSFSheet xssfSheet;
	XSSFRow xssfRow;
	XSSFCell xssfCell;

	public XSLX(File filePrdOrig, File filePrdMod) {
		super();
		this.filePrdOrig = filePrdOrig;
		this.filePrdMod = filePrdMod;
	}

	public void openFileXSLX() throws IOException {
		System.out.println("Opening Document");
		try {
			fileInputS = new FileInputStream(filePrdOrig);
			LOGGER.log(Level.INFO, " Document open Succesfull: " +filePrdOrig);
		}catch (FileNotFoundException e) {
			LOGGER.log(Level.SEVERE, e + " NOT FOUND: " +filePrdOrig);
		}
		try {
			fileXSLX = new XSSFWorkbook(fileInputS);
			LOGGER.log(Level.INFO, " PROCESSING FILE OK");
		}catch(NullPointerException e) {
			LOGGER.log(Level.WARNING, e + "" );
		}
	}

	public void writeFileXSLX() throws IOException {
		System.out.println("Writing Document");
		fileInputS.close();
		fileOutputS = new FileOutputStream(filePrdMod);
		fileXSLX.write(fileOutputS);
		System.out.println("Document write Succesfull");
		fileXSLX.close();
		fileOutputS.close();
		System.out.println("Close Document");
	}

	public void writeValueXSLX(String sheetName, int row, int cell, String value) {
		try {
			xssfSheet = fileXSLX.getSheet(sheetName);
			LOGGER.log(Level.INFO, "\t\tREADING SHETT : " +sheetName);
		}catch (NullPointerException e) {
			LOGGER.log(Level.SEVERE, e + " NOT FOUND SHEET: " +sheetName);
		}
		
		try {
			xssfRow = xssfSheet.getRow(row);
			LOGGER.log(Level.INFO, "\t\tREADING ROW : " +row);
		}catch (NullPointerException e) {
			LOGGER.log(Level.SEVERE, e + " NOT FOUND ROW: " +row);
			try {
			createRow(row);
			}catch (NullPointerException npe) {
				LOGGER.log(Level.SEVERE, npe + " NOT FOUND SHEET: " +sheetName);
				xssfSheet =  createSheet(sheetName);
				xssfRow = createRow(row);
			}
			
		}
		
		try {
			xssfCell = xssfRow.getCell(cell);
			LOGGER.log(Level.INFO, "\t\tPREPARING CELL : " +cell);
		}catch (NullPointerException e) {
			LOGGER.log(Level.SEVERE, e + " NOT FOUND CELL: " +cell);

			try {
				createCell(cell);
				xssfCell = xssfRow.getCell(cell);
			}catch (NullPointerException npe) {

				LOGGER.log(Level.SEVERE, e + " ERROR CREATING CELL: " +cell);
				xssfRow = createRow(row);
				createCell(cell);
				xssfCell = xssfRow.getCell(cell);
			}
		}
		
		try {
			xssfCell.setCellValue(value);
			LOGGER.log(Level.INFO, "WRITE VALUE SUCCESSFULL : " +value);
		}catch (Exception e) {
			LOGGER.log(Level.WARNING, e +"||ERROR ESCRIBIENDO VALOR : " +value + " EN LA CELDA (" + row +"," +cell +")");
			createCell(cell);
			xssfCell = xssfRow.getCell(cell);
			LOGGER.log(Level.INFO, "\t\tPREPARING CELL : " +cell);
			xssfCell.setCellValue(value);
			LOGGER.log(Level.INFO, "WRITE VALUE SUCCESSFULL : " +value);
		}
	}
	
	private XSSFRow createRow(int index) {
		LOGGER.log(Level.INFO, "\t\t\tCREATING ROW : " +index);
		XSSFRow row = xssfSheet.createRow(index);
		LOGGER.log(Level.INFO, "\t\t\tROW CREATED : " +index);	
		return row;
	}
	
	private XSSFCell createCell(int index) {
		LOGGER.log(Level.INFO, "\t\t\tCREATING CELL : " +index);
		XSSFCell cell = xssfRow.createCell(index);
		LOGGER.log(Level.INFO, "\t\t\tCELL CREATED : " +index);
		return cell;
	}
	
	private XSSFSheet createSheet(String sheetName) {
		LOGGER.log(Level.INFO, "\t\t\tCREATING SHEET : " +sheetName);
		XSSFSheet shett = fileXSLX.createSheet(sheetName);
		LOGGER.log(Level.INFO, "\t\t\tSHETT CREATED : " +sheetName);
		return shett;
	}
}
