package edit_xlsx_01;

import edit_xlsx_01.XSLX;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
	
	static final Logger LOGGER = Logger.getLogger("Main");
	
	static XSLX xslxPoi;
	static File filePrdOrig;
	static File filePrdMod;
	static contentProperties cp;

	public static void main(String[] args) throws IOException {

		cp = new contentProperties();

		String fileNameOrigin = cp.getFileNameOrigin(new StringBuilder("hip"));
		String filePathOrigin = cp.getFilePathOrigin(new StringBuilder("hip"));
		String fileNameMod = cp.getFileNameMod(new StringBuilder("hip"));
		String filePathMod = cp.getFilePathMod(new StringBuilder("hip"));

		filePrdOrig = new File(filePathOrigin + fileNameOrigin);
		filePrdMod = new File(filePathMod + fileNameMod);

		LOGGER.log(Level.INFO, "Iniciando proceso");
		xslxPoi = new XSLX(filePrdOrig, filePrdMod);
		xslxPoi.openFileXSLX();
		setValue("analistaSoporte");
		//setValue("validacionPostPase");
		xslxPoi.writeFileXSLX();

	}

	private static void setValue(String value) throws IOException {
		xslxPoi.writeValueXSLX(
				"Instrucciones",
				cp.getRow(new StringBuilder(value)),
				cp.getCell(new StringBuilder(value)),
				cp.getValue(new StringBuilder(value)));
	}

}
