package edit_xlsx_01;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class contentProperties {
	InputStream inputStreamValue, inputStreamPosition, inputStreamFile;
	Properties propValue, propPosition, propFile = null;
	StringBuilder propValueFileName, propPositionFileName, propFileFileName;

	public contentProperties() {
		// TODO Auto-generated constructor stub

		try {
			loadProperties();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getValue(StringBuilder value) throws IOException {
		return propValue.getProperty(value.toString());
	}

	public int getRow(StringBuilder value) throws IOException {
		return Integer.parseInt(propPosition.getProperty(value.toString() + ".row"));
	}

	public int getCell(StringBuilder value) throws IOException {
		return Integer.parseInt(propPosition.getProperty(value.toString() + ".cell"));
	}
	
	public String getFileNameMod(StringBuilder value) throws IOException {
		return propFile.getProperty(value.toString() + ".name.destino");
	}
	
	public String getFilePathMod(StringBuilder value) throws IOException {
		return propFile.getProperty(value.toString() + ".path.destino");
	}
	
	public String getFileNameOrigin(StringBuilder value) throws IOException {
		return propFile.getProperty(value.toString() + ".name.origen");
	}
	
	public String getFilePathOrigin(StringBuilder value) throws IOException {
		return propFile.getProperty(value.toString() + ".path.origen");
	}
	
	private void loadProperties() throws IOException {

		propValue = new Properties();
		propPosition = new Properties();
		propFile = new Properties();

		propValueFileName = new StringBuilder("content.properties");
		propPositionFileName = new StringBuilder("position.properties");
		propFileFileName = new StringBuilder("file.properties");

		inputStreamValue = getClass().getClassLoader().getResourceAsStream(propValueFileName.toString());
		inputStreamPosition = getClass().getClassLoader().getResourceAsStream(propPositionFileName.toString());
		inputStreamFile = getClass().getClassLoader().getResourceAsStream(propFileFileName.toString());

		if (inputStreamValue != null) {
			propValue.load(inputStreamValue);
		} else {
			throw new FileNotFoundException(
					"property file '" + propValueFileName.toString() + "' not found in the classpath");
		}

		if (inputStreamPosition != null) {
			propPosition.load(inputStreamPosition);
		} else {
			throw new FileNotFoundException(
					"property file '" + propPositionFileName.toString() + "' not found in the classpath");
		}
		
		if (inputStreamFile != null) {
			propFile.load(inputStreamFile);
		} else {
			throw new FileNotFoundException(
					"property file '" + propFileFileName.toString() + "' not found in the classpath");
		}
	}
}
